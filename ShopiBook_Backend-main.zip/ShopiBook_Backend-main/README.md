# ShopiBook_Backend
### We implement following modules.
1. Login
2. Register
3. User Master
4. Book Master
5. Global Search
6. Cart
7. Publisher
8. Update Profile

### CRUD operation with Model-View-Controller (MVC) framework.
### pgAdmin4 as a database.
### Build in .net version 5.0
### command to integret backend is : 
dotnet ef dbcontext scaffold "Server=localhost;Port=5432;Database=postgres;User Id=postgres;Password=xxxx;" Npgsql.EntityFrameworkCore.PostgreSQL -o DataModels

